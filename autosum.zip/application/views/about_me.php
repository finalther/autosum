<style>
.row {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  flex-wrap: wrap;
}
.row > [class*='col-'] {
  display: flex;
  flex-direction: column;
}
.row .col-md-3 {
  background-image:url("../assets/img/");
}
ul>li{
  color: #8A9CA0;;
}
</style>
  <div class="container">
    <h3 style="text-align:center;color:#BDC7C9;">Tentang Saya </h1>
  <div class="row" style="background-color: #FFFFFF;padding:20px;">
    <div class="col-md-3" style="background-color: #646464;">
    </div>
    <div class="col-md-6" style="color:#BDC7C9;">  
        <p style="text-align:justify;">Saya adalah orang yang sangat flexibel, multitask, menyukai dengan rutinitas, loyalitas, disiplin dan sesuatu yang terjadwal. Ketika dihadapkan dalam sebuah permasalahan, saya lebih menyukai untuk menganalisis dengan mencari indikator utama penyebabnya sebelum mengambil keputusan. </p>
          <h4 style="color:gray ">Riwayat Pendidikan </h4>
          <ul>
              <li>2001 - 2007    : SDN Blaru 2 </li>
              <li>2007 - 2010    : SMPN 2 PARE </li>
              <li>2010 - 2013    : SMAN 1 PARE  </li>
              <li>2013 - 2017    : Teknik Informatika/Fakultas Ilmu Komputer, Universitas Brawijaya</li>
              <li>2017 - Sekarang: Bekerja di IT konsultan </li>
          </ul>  
          <h4 style="color:gray ">Kemampuan </h4>
          <ul>
              <li>PHP</li>
              <li>MySQL</li>
              <li>Bootstrap</li>
              <li>Code Igniter</li>
              <li>Javascript, Jquery</li>
              <li>HTML, CSS</li>
          </ul>  
          <h4 style="color:gray ">Motivasi </h4>
          <ul>
            <li style="list-style: none"><p>"Menjadi seorang yang berkomitmen dan memiliki loyalitas yang tinggi bukanlah hal yang mudah, Tapi hal itu bisa dilakukan oleh orang yang memiliki integritas tinggi!."</p></li>
          </ul>  
    </div>
  </div>
